﻿const { DatabaseSync } = require('node:sqlite');
const bcrypt = require('bcrypt');
const path = require('path');
const fs = require('fs');
const dbDir = path.join(__dirname, '..', 'database');
fs.mkdirSync(dbDir, { recursive: true });
const db = new DatabaseSync(path.join(dbDir, 'craftly.db'));
db.exec('PRAGMA foreign_keys = ON');

function initDatabase() {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT, username TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL, email TEXT UNIQUE NOT NULL, phone TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'user', created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS applications (
      id INTEGER PRIMARY KEY AUTOINCREMENT, user_id INTEGER NOT NULL REFERENCES users(id),
      project_type TEXT NOT NULL, budget TEXT, deadline TEXT, description TEXT,
      reference_url TEXT, status TEXT NOT NULL DEFAULT 'new', stage TEXT DEFAULT 'Бриф',
      admin_comment TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
      updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
    CREATE TABLE IF NOT EXISTS audit_log (
      id INTEGER PRIMARY KEY AUTOINCREMENT, admin_id INTEGER NOT NULL REFERENCES users(id),
      application_id INTEGER REFERENCES applications(id), action TEXT NOT NULL,
      details TEXT, created_at DATETIME DEFAULT CURRENT_TIMESTAMP
    );
  `);
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get('Knayfes');
  if (!existing) {
    db.prepare('INSERT INTO users (username, password_hash, email, phone, role) VALUES (?, ?, ?, ?, ?)')
      .run('Knayfes', bcrypt.hashSync('300919819', 10), 'admin@craftly.local', '+70000000000', 'admin');
  }
}
module.exports = { db, initDatabase };
